<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Category_Attribute extends Model
{
    //
    protected $table = 'category_attribute';
}
