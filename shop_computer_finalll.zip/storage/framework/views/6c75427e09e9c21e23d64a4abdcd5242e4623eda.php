
<?php if($category): ?>
    <?php $__currentLoopData = $category->Attributes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $at): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($at->at_type=="text"): ?>
            <div class="form-group">
                <label><?php echo e($at->at_name); ?>: </label>
                <input type="text" name="<?php echo e($at->id); ?>" required value="<?php echo e(isset($product)?dataAttributeValue($at,$product):""); ?>" class="form-control"/>
            </div>
        <?php endif; ?>
        <?php if($at->at_type == "number"): ?>
            <div class="form-group">
                <label><?php echo e($at->at_name); ?>: </label>
                <input type="number" name="<?php echo e($at->id); ?>" required value="<?php echo e(isset($product)?dataAttributeValue($at,$product):""); ?>" class="form-control"/>
            </div>
        <?php endif; ?>
        <?php if($at->at_type == "numberfloat"): ?>
            <div class="form-group">
                <label><?php echo e($at->at_name); ?>: </label>
                <input type="number" step="any" name="<?php echo e($at->id); ?>" required value="<?php echo e(isset($product)?dataAttributeValue($at,$product):""); ?>" class="form-control"/>
            </div>
        <?php endif; ?>
        <?php if($at->at_type=="select"): ?>
            <div class="form-group">
                <label><?php echo e($at->at_name); ?>: </label>
                <select name="<?php echo e($at->id); ?>" class="form-control">
                    <?php $__currentLoopData = explode(';',$at->at_value); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($value); ?>" <?php echo e(isset($product)?(checkDataAttributeValue($at,$product,$value)?"selected":""):""); ?>><?php echo e($value); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        <?php endif; ?>
        
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\shop_computer\resources\views/admin/product/getattribute.blade.php ENDPATH**/ ?>