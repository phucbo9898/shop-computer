<?php echo csrf_field(); ?>
<div class="form-group">
    <label>Tên loại sản phẩm: </label>
    <input type="text" class="form-control" name="c_name" value="<?php echo e(old('c_name',isset($category->c_name)?$category->c_name:'')); ?>" placeholder="Nhập tên loại sản phẩm...">
</div>
<div class="form-group row">
    <label class="col-md-2">Trạng thái: </label>
    <div class="form-check  col-md-4">
        <input class="form-check-input" type="radio" name="c_status" value="1" <?php echo e(isset($category->c_status)?(($category->c_status==1)?'checked':''):'checked'); ?>>
        <label class="form-check-label" for="c_status">
          Public
        </label>
      </div>
      <div class="form-check  col-md-4">
        <input class="form-check-input" type="radio" name="c_status" value="0" <?php echo e(isset($category->c_status)?(($category->c_status==1)?'':'checked'):''); ?>>
        <label class="form-check-label" for="c_status">
          Private
        </label>
      </div>
</div>
<div class="form-group">
    <label>Thuộc tính: </label>
    <?php $__currentLoopData = $attributes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attribute): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="form-check">
      <label class="form-check-label">
        <input type="checkbox" class="form-check-input" name="<?php echo e($attribute->id); ?>" <?php echo e(isset($arrayCategoryAttribute)?((in_array($attribute->id,$arrayCategoryAttribute))?"checked":""):""); ?>><?php echo e($attribute->at_name); ?>

      </label>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<input type="submit" value="Lưu thông tin" class="btn btn-success btn_save_category" style="float: right"/>
<div style="clear: both"></div>
<?php /**PATH C:\xampp\htdocs\shop_computer\resources\views/Admin/category/form.blade.php ENDPATH**/ ?>