<?php $__env->startSection('content'); ?>
<!-- Begin Li's Breadcrumb Area -->
<div class="breadcrumb-area">
    <div class="container">
        <div class="breadcrumb-content">
            <ul>
                <li><a href="<?php echo e(route('home')); ?>">Trang chủ</a></li>
                <li class="active">Lấy lại mật khẩu - đổi mật khẩu tài khoản: <?php echo e($email); ?></li>
            </ul>
        </div>
    </div>
</div>
<!-- Li's Breadcrumb Area End Here -->
<div class="pt-60 pb-50">
    <form class="col-6 mx-auto" method="POST">
        <?php if(!$errors->resetPasswordErrors->isEmpty()): ?>
                  <?php $__currentLoopData = $errors->resetPasswordErrors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                      <?php echo e($err); ?>

                      <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                      </button>
                    </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label>Mật khẩu mới: </label>
            <input type="password" name="passwordreset" class="form-control"/>
        </div>
        <div class="form-group">
            <label>Nhập lại mật khẩu: </label>
            <input type="password" name="confirm_passwordreset" class="form-control"/>
        </div>
        <input type="submit" value="Đổi mật khẩu" class="btn btn-success col-4" style="float: right"/>
        <div style="clear: both"></div>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('customer.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shop_computer\resources\views/customer/auth/change_reset_password.blade.php ENDPATH**/ ?>