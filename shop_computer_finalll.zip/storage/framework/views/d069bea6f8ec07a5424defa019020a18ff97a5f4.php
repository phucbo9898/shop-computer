<?php $__env->startSection('content'); ?>
<!-- Begin Li's Breadcrumb Area -->
<div class="breadcrumb-area">
    <div class="container">
        <div class="breadcrumb-content">
            <ul>
                <li><a href="<?php echo e(route('home')); ?>">Trang chủ</a></li>
                <li class="active">Giỏ hàng</li>
            </ul>
        </div>
    </div>
</div>
<!-- Li's Breadcrumb Area End Here -->
<!--Shopping Cart Area Strat-->
<div class="Shopping-cart-area pt-60 pb-60">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <?php if(\Session::has('success')): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <strong>Thành công!</strong> <?php echo e(\Session::get('success')); ?>

                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                    </button>
                  </div>
                <?php endif; ?>
                <?php if(\Session::has('warning')): ?>
                <div class="alert alert-warning alert-dismissible fade show" role="alert">
                    <strong>Thất bại!</strong> <?php echo e(\Session::get('warning')); ?>

                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                    </button>
                  </div>
                <?php endif; ?>
                    <div class="table-content table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th class="li-product-remove">Xóa</th>
                                    <th class="li-product-thumbnail">Ảnh</th>
                                    <th class="cart-product-name">Tên sản phẩm</th>
                                    <th class="li-product-price">Giá</th>
                                    <th class="li-product-quantity">Số lượng</th>
                                    <th class="li-product-subtotal">Tổng</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="li-product-remove"><a href="<?php echo e(route('shopping.delete.product',$key)); ?>"><i class="fa fa-times"></i></a></td>
                                    <?php if($product->options->image): ?>
                                        <td class="li-product-thumbnail" style="width: 16%"><a href="#"><img style="width: 100%; height: 150px;" src="<?php echo e(asset('upload/pro_image/'.$product->options->image)); ?>" alt="Li's Product Image"></a></td>
                                    <?php else: ?>
                                        <td class="li-product-thumbnail" style="width: 16%"><a href="#"><img style="width: 100%; height: 150px;" src="<?php echo e(asset('noimg.png')); ?>" alt="Li's Product Image"></a></td>
                                    <?php endif; ?>
                                    <td class="li-product-name"><a href="#"><?php echo e($product->name); ?></a></td>
                                    <td class="li-product-price"><span class="amount"><?php echo e(number_format($product->price,2,',','.')); ?> VNĐ</span></td>
                                    <td class="quantity">
                                        <form action="<?php echo e(route('shopping.edit.product')); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <input type="hidden" name="pro_id" value="<?php echo e($product->id); ?>"/>
                                            <span style="color: #242424l;font-size: 16px;font-weight: 700;"><?php echo e($product->qty); ?> Sản phẩm</span>
                                            <div class="cart-plus-minus">
                                                <input class="cart-plus-minus-box" value="<?php echo e($product->qty); ?>" name="number_product_edit" type="number" min="0" max="10">
                                                <div class="dec qtybutton"><i class="fa fa-angle-down"></i></div>
                                                <div class="inc qtybutton"><i class="fa fa-angle-up"></i></div>
                                            </div>
                                            <button class="btn btn-primary mt-2">Cập nhật</button>
                                        </form>
                                    </td>
                                    <td class="product-subtotal"><span class="amount"><?php echo e(number_format($product->price*$product->qty,2,',','.')); ?> VNĐ<br/> Thành: <?php echo e(number_format($product->price*$product->qty,0,',','.')); ?> VNĐ</span></td>
                                </tr>                                   
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="row">
                        <div class="col-md-5 ml-auto">
                            <div class="cart-page-total">
                                <h2>Tổng tiền cần thanh toán:</h2>
                                <ul>
                                    <li>Tổng <span><?php echo e(\Cart::subtotal(0,',','.')); ?> VNĐ</span></li>
                                </ul>
                                <?php if(\Cart::subtotal()>0): ?>
                                <a href="<?php echo e(route('feature.user.checkout')); ?>" style="float: right">Xác nhận đặt hàng</a>
                                <?php endif; ?>
                                <div style="clear: both"></div>
                            </div>
                        </div>
                    </div>
            </div>
        </div>
    </div>
</div>
<!--Shopping Cart Area End-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('customer.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shop_computer\resources\views/customer/shoppingCart/index.blade.php ENDPATH**/ ?>