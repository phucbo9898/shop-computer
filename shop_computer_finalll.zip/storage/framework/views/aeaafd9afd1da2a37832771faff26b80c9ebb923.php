<?php $__env->startSection('content'); ?>
<style>
	.ellipsis {
	white-space: nowrap;
    text-overflow: ellipsis;
    overflow: hidden;
    }
	.block-ellipsis {
	display: -webkit-box;
	max-width: 100%;
	height: 40px;
	margin: 0 auto;
	-webkit-line-clamp: 2;
	-webkit-box-orient: vertical;
	overflow: hidden;
	text-overflow: ellipsis;
    }
    .block-ellipsis-description{
	display: -webkit-box;
	max-width: 100%;
	height: 50px;
	margin: 0 auto;
	-webkit-line-clamp: 2;
	-webkit-box-orient: vertical;
	overflow: hidden;
	text-overflow: ellipsis;
    margin-bottom: 6px;
    }
</style>
<!-- Begin Slider With Category Menu Area -->
<div class="slider-with-banner">
    <div class="container">
        <div class="row">
            <!-- Begin Category Menu Area -->
            <div class="col-lg-3">
                <!--Category Menu Start-->
                <div class="category-menu">
                    <div class="category-heading">
                        <h2 class="categories-toggle"><span>loại sản phẩm</span></h2>
                    </div>
                    <div id="cate-toggle" class="category-menu-list">
                        <?php
                            $numberListCategory = 1;
                        ?>
                        <ul>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($numberListCategory <=8 ): ?>
                                <li class=""><a href="<?php echo e(route('category.index',[$category->c_name_slug,$category->id])); ?>"><?php echo e($category->c_name); ?></a>  
                                    </li>
                                <?php endif; ?>
                                <?php if($numberListCategory >8 ): ?>
                                    <li class="rx-child"><a href="#"><?php echo e($category->c_name); ?></a></li>
                                <?php endif; ?>
                                <?php $numberListCategory++ ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                            <li class="rx-parent">
                                <a class="rx-default">Hiển thị thêm loại sản phẩm</a>
                                <a class="rx-show">Ẩn bớt loại sản phẩm</a>
                            </li>
                        </ul>
                    </div>
                </div>
                <!--Category Menu End-->
            </div>
            <!-- Category Menu Area End Here -->
            <!-- Begin Slider Area -->
            <div class="col-lg-9">
                <div class="slider-area pt-sm-30 pt-xs-30">
                    <div class="slider-active owl-carousel">
                        <!-- Begin Single Slide Area -->
                        <?php $__currentLoopData = $slides; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slide): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="single-slide align-center-left animation-style-02" style="
                            background-image: url(<?php echo e(asset('upload/s_image/'.$slide->s_avatar)); ?>);
                            background-repeat: no-repeat;
                            background-position: center center;
                            background-size: cover;
                            min-height: 475px;
                            width: 100%;">
                            <div class="slider-progress"></div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
            <!-- Slider Area End Here -->
        </div>
    </div>
</div>
<!-- Slider With Category Menu Area End Here -->
<!-- Begin Li's Special Product Area -->
<section class="product-area li-laptop-product Special-product pt-60 pb-45">
    <div class="container">
        <div class="row">
            <!-- Begin Li's Section Area -->
            <div class="col-lg-12">
                <div class="li-section-title">
                    <h2>
                        <span>SẢN PHẨM MỚI CẬP NHẬT</span>
                    </h2>
                </div>
                <div class="row">
                    <div class="special-product-active owl-carousel">
                        <?php $__currentLoopData = $product_news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>              
                        <div class="col-lg-12">
                            <!-- single-product-wrap start -->
                            <div class="single-product-wrap">
                                <div class="product-image">
                                    <a href="<?php echo e(route('product.index',[$prn->pro_name_slug,$prn->id])); ?>">
                                        <?php if(isset($prn->pro_image)): ?>
                                            <img src="<?php echo e(asset('upload/pro_image/'.$prn->pro_image)); ?>" alt="Li's Product Image">
                                        <?php else: ?>
                                            <img src="<?php echo e(asset('noimg.png')); ?>" alt="Li's Product Image">
                                        <?php endif; ?>
                                    </a>
                                    <?php if($prn->pro_hot == 1): ?>
                                        <span class="sticker">Hot</span>
                                    <?php endif; ?>
                                </div>
                                <div class="product_desc">
                                    <div class="product_desc_info">
                                        <div class="product-review">
                                            <h5 class="manufacturer">
                                                
                                                <div class="rating-box">
                                                    <?php
                                                    $point= 0;
                                                    if($prn->pro_number_of_reviewers>0){
                                                        $point_product_new= round($prn->pro_total_star/$prn->pro_number_of_reviewers);
                                                    }
                                                    else {
                                                        $point_product_new = -1;
                                                    }
                                                    ?>
                                                    <ul class="rating">
                                                        <?php if($point_product_new == -1): ?>
                                                            <li style="color: #a4a4a4;
                                                            font-size: 13px;
                                                            text-transform: capitalize;
                                                            transition: all 0.3s ease-in-out;">Chưa đánh giá</li>
                                                        <?php else: ?>
                                                        Đánh Giá:  
                                                            <?php for($i=1; $i<=5; $i++): ?>
                                                                <li class="<?php echo e($i<=$point_product_new ? '':'no-star'); ?>"><i class="fa fa-star"></i></li>
                                                            <?php endfor; ?>
                                                        <?php endif; ?>
                                                    </ul>
                                                </div>
                                            </h5>
                                            
                                        </div>
                                        <h4><a class="product_name" href="<?php echo e(route('product.index',[$prn->pro_name_slug,$prn->id])); ?>"><?php echo e($prn->pro_name); ?></a></h4>
                                        <div class="price-box">
                                            <?php if($prn->pro_sale>0): ?>
                                                <span class="new-price new-price-2"><?php echo e(number_format(($prn->pro_price*(100-$prn->pro_sale))/100,0,",",".")); ?> VNĐ</span>
                                                <span class="discount-percentage">-<?php echo e($prn->pro_sale); ?>%</span><br/>
                                                <div class="old-price" style="padding-top: 6px"><?php echo e(number_format($prn->pro_price,0,",",".")); ?> VNĐ</div>
                                            <?php else: ?>
                                                <span class="new-price"><?php echo e(number_format($prn->pro_price,0,",",".")); ?> VNĐ</span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="add-actions">
                                        <ul class="add-actions-link">
                                            <li class="add-cart active"><a class="button_add_cart" data-product-name="<?php echo e($prn->pro_name); ?>" href="<?php echo e(route('shopping.add.product',$prn->id)); ?>">Mua sản phẩm</a></li>
                                            <li><a class="links-details button_add_favorite_product" data-product-name="<?php echo e($prn->pro_name); ?>" href="<?php echo e(route('get.add.favorite.product',$prn->id)); ?>"><i class="fa fa-heart-o"></i></a></li>
                                            <li><a href="<?php echo e(route('product.index',[$prn->pro_name_slug,$prn->id])); ?>" title="quick view" class="quick-view-btn"><i class="fa fa-eye"></i></a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <!-- single-product-wrap end -->
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
            <!-- Li's Section Area End Here -->
        </div>
    </div>
</section>
<!-- Li's Special Product Area End Here -->
<!-- Begin Li's Trending Product | Home V2 Area -->
<section class="product-area li-trending-product li-trending-product-2 pb-45">
    <div class="container">
        <div class="row">
            <!-- Begin Li's Tab Menu Area -->
            <div class="col-lg-12">
                <div class="li-section-title">
                    <h2>
                        <span>SẢN PHẨM BÁN CHẠY</span>
                    </h2>
                </div>           
                <!-- Begin Li's Tab Menu Content Area -->
                <div class="tab-content li-tab-content li-trending-product-content">
                    <div id="home1" class="tab-pane show fade in active">
                        <div class="row">
                            <div class="product-active owl-carousel">
                                <?php $__currentLoopData = $product_best_pays; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product_best_pay): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-lg-12">
                                    <!-- single-product-wrap start -->
                                        <div class="single-product-wrap">
                                            <div class="product-image">
                                                <a href="<?php echo e(route('product.index',[$product_best_pay->pro_name_slug,$product_best_pay->id])); ?>">
                                                    <?php if(isset($product_best_pay->pro_image)): ?>
                                                        <img src="<?php echo e(asset('upload/pro_image/'.$product_best_pay->pro_image)); ?>" alt="Li's Product Image">
                                                    <?php else: ?>
                                                        <img src="<?php echo e(asset('noimg.png')); ?>" alt="Li's Product Image">
                                                    <?php endif; ?>
                                                </a>
                                                <?php if($product_best_pay->pro_hot == 1): ?>
                                                    <span class="sticker">Hot</span>
                                                <?php endif; ?>
                                            </div>
                                            <div class="product_desc">
                                                <div class="product_desc_info">
                                                    <div class="product-review">
                                                        <h5 class="manufacturer">
                                                            <div class="rating-box">
                                                                <?php
                                                                $point_product_best_pay= 0;
                                                                if($product_best_pay->pro_number_of_reviewers>0){
                                                                    $point_product_best_pay= round($product_best_pay->pro_total_star/$product_best_pay->pro_number_of_reviewers);
                                                                }
                                                                else {
                                                                    $point_product_best_pay = -1;
                                                                }
                                                                ?>
                                                                <ul class="rating">
                                                                    <?php if($point_product_best_pay == -1): ?>
                                                                        <li style="color: #a4a4a4;
                                                                        font-size: 13px;
                                                                        text-transform: capitalize;
                                                                        transition: all 0.3s ease-in-out;">Chưa đánh giá</li>
                                                                    <?php else: ?>
                                                                    Đánh Giá: 
                                                                        <?php for($i=1; $i<=5; $i++): ?>
                                                                            <li class="<?php echo e($i<=$point_product_best_pay ? '':'no-star'); ?>"><i class="fa fa-star"></i></li>
                                                                        <?php endfor; ?>
                                                                    <?php endif; ?>
                                                                </ul>
                                                            </div>
                                                        </h5>
                                                        
                                                    </div>
                                                    <h4><a class="product_name" href="<?php echo e(route('product.index',[$product_best_pay->pro_name_slug,$product_best_pay->id])); ?>"><?php echo e($product_best_pay->pro_name); ?></a></h4>
                                                    <div class="price-box">
                                                        <?php if($product_best_pay->pro_sale>0): ?>
                                                            <span class="new-price new-price-2"><?php echo e(number_format(($product_best_pay->pro_price*(100-$product_best_pay->pro_sale))/100,0,",",".")); ?> VNĐ</span>
                                                            <span class="discount-percentage">-<?php echo e($product_best_pay->pro_sale); ?>%</span><br/>
                                                            <div class="old-price" style="padding-top: 6px"><?php echo e(number_format($product_best_pay->pro_price,0,",",".")); ?> VNĐ</div>
                                                        <?php else: ?>
                                                            <span class="new-price"><?php echo e(number_format($product_best_pay->pro_price,0,",",".")); ?> VNĐ</span>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                                <div class="add-actions">
                                                    <ul class="add-actions-link">
                                                        <li class="add-cart active"><a class="button_add_cart" data-product-name="<?php echo e($product_best_pay->pro_name); ?>" href="<?php echo e(route('shopping.add.product',$product_best_pay->id)); ?>">Mua sản phẩm</a></li>
                                                        <li><a class="links-details button_add_favorite_product" data-product-name="<?php echo e($product_best_pay->pro_name); ?>" href="<?php echo e(route('get.add.favorite.product',$product_best_pay->id)); ?>"><i class="fa fa-heart-o"></i></a></li>
                                                        <li><a href="<?php echo e(route('product.index',[$product_best_pay->pro_name_slug,$product_best_pay->id])); ?>" title="quick view" class="quick-view-btn"><i class="fa fa-eye"></i></a></li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>     
                                    <!-- single-product-wrap end -->
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Tab Menu Content Area End Here -->
            </div>
            <!-- Tab Menu Area End Here -->
        </div>
    </div>
</section>
<!-- Li's Trending Product | Home V2 Area End Here -->
<!-- Begin Li's Main Blog Page Area -->
<div class="li-main-blog-page pb-45">
    <div class="container">
        <div class="row">
            <!-- Begin Li's Main Content Area -->
            <div class="col-lg-12">
                <div class="li-section-title">
                    <h2>
                        <span>Bài viết mới nhất</span>
                    </h2>
                </div>
                <div class="row li-main-content" style="margin-top: 22px;">
                    <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-4 col-md-6">
                        <div class="li-blog-single-item pb-25">
                            <div class="li-blog-banner">
                                <a href="<?php echo e(route('get.article.detail',$article->id)); ?>"><img class="img-full" src="<?php echo e(asset('upload/a_image/'.$article->a_image)); ?>" alt=""></a>
                            </div>
                            <div class="li-blog-content">
                                <div class="li-blog-details">
                                    <h5 class="li-blog-heading pt-25"><a href="<?php echo e(route('get.article.detail',$article->id)); ?>" class="block-ellipsis"><?php echo e($article->a_name); ?></a></h5>
                                    <div class="li-blog-meta" style="padding: 0px 0 10px;">
                                        <a class="author" href="#"><i class="fa fa-user"></i><?php echo e(isset($article->User->name)?$article->User->name:'Admin'); ?></a>
                                        <a class="post-time" href="#"><i class="fa fa-calendar"></i> <?php echo e($article->created_at); ?></a>
                                    </div>
                                    <p class="block-ellipsis-description"><?php echo e($article->a_description); ?></p>
                                    <a class="read-more" href="<?php echo e(route('get.article.detail',$article->id)); ?>">Xem thêm...</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                </div>
            </div>
            <!-- Li's Main Content Area End Here -->
        </div>
    </div>
</div>
<!-- Li's Main Blog Page Area End Here -->
<!-- Begin Li's Laptops Product | Home V2 Area -->
<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if($category->Product->where('pro_status',1)->count()>=5): ?>
<section class="product-area li-laptop-product li-laptop-product-2 pb-45">
    <div class="container">
        <div class="row">
            <!-- Begin Li's Section Area -->
            <div class="col-lg-12">
                <div class="li-section-title">
                    <h2>
                        <span><?php echo e($category->c_name); ?></span>
                    </h2>
                </div>
                <div class="row">
                    <div class="product-active owl-carousel">
                        <?php $__currentLoopData = $category->Product->where('pro_status',1)->sortByDesc('id')->take(5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-12">
                            <!-- single-product-wrap start -->
                                <div class="single-product-wrap">
                                    <div class="product-image">
                                        <a href="<?php echo e(route('product.index',[$product->pro_name_slug,$product->id])); ?>">
                                            <?php if(isset($product->pro_image)): ?>
                                                <img src="<?php echo e(asset('upload/pro_image/'.$product->pro_image)); ?>" alt="Li's Product Image">
                                            <?php else: ?>
                                                <img src="<?php echo e(asset('noimg.png')); ?>" alt="Li's Product Image">
                                            <?php endif; ?>
                                        </a>
                                        <?php if($product->pro_hot == 1): ?>
                                            <span class="sticker">Hot</span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="product_desc">
                                        <div class="product_desc_info">
                                            <div class="product-review">
                                                <h5 class="manufacturer">
                                                    <div class="rating-box">
                                                        <?php
                                                        $point= 0;
                                                        if($product->pro_number_of_reviewers>0){
                                                            $point= round($product->pro_total_star/$product->pro_number_of_reviewers);
                                                        }
                                                        else {
                                                            $point = -1;
                                                        }
                                                        ?>
                                                        <ul class="rating">
                                                            <?php if($point == -1): ?>
                                                                <li style="color: #a4a4a4;
                                                                font-size: 13px;
                                                                text-transform: capitalize;
                                                                transition: all 0.3s ease-in-out;">Chưa đánh giá</li>
                                                            <?php else: ?>
                                                            Đánh Giá: 
                                                                <?php for($i=1; $i<=5; $i++): ?>
                                                                    <li class="<?php echo e($i<=$point ? '':'no-star'); ?>"><i class="fa fa-star"></i></li>
                                                                <?php endfor; ?>
                                                            <?php endif; ?>
                                                        </ul>
                                                    </div>
                                                </h5>
                                            </div>
                                            <h4><a class="product_name" href="<?php echo e(route('product.index',[$product->pro_name_slug,$product->id])); ?>"><?php echo e($product->pro_name); ?></a></h4>
                                            <div class="price-box">
                                                <?php if($product->pro_sale>0): ?>
                                                    <span class="new-price new-price-2"><?php echo e(number_format(($product->pro_price*(100-$product->pro_sale))/100,0,",",".")); ?> VNĐ</span>
                                                    <span class="discount-percentage">-<?php echo e($product->pro_sale); ?>%</span><br/>
                                                    <div class="old-price" style="padding-top: 6px"><?php echo e(number_format($product->pro_price,0,",",".")); ?> VNĐ</div>
                                                <?php else: ?>
                                                    <span class="new-price"><?php echo e(number_format($product->pro_price,0,",",".")); ?> VNĐ</span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <div class="add-actions">
                                            <ul class="add-actions-link">
                                                <li class="add-cart active"><a class="button_add_cart" data-product-name="<?php echo e($product->pro_name); ?>" href="<?php echo e(route('shopping.add.product',$product->id)); ?>">Mua sản phẩm</a></li>
                                                <li><a class="links-details button_add_favorite_product" data-product-name="<?php echo e($product->pro_name); ?>" href="<?php echo e(route('get.add.favorite.product',$product->id)); ?>"><i class="fa fa-heart-o"></i></a></li>
                                                <li><a href="<?php echo e(route('product.index',[$product->pro_name_slug,$product->id])); ?>" title="quick view" class="quick-view-btn"><i class="fa fa-eye"></i></a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>     
                            <!-- single-product-wrap end -->
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
                    </div>
                </div>
            </div>
            <!-- Li's Section Area End Here -->
        </div>
    </div>
</section>
<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<!-- Li's Laptops Product | Home V2 Area End Here -->

<?php $__env->stopSection(); ?>
<?php $__env->startSection('javascript'); ?>
<script>
    $(function(){
        $(".button_add_favorite_product").click(function(event)
        {
            event.preventDefault();
            url = $(this).attr("href");
            name_product = $(this).attr("data-product-name");
            $.ajax(
                {
                    method : "GET",
                    url : url
                }
            ).done(function(result)
            {
                if(result.status == 1)
                {
                    swal("Thành công !","Đã thêm sản phẩm "+name_product+" vào sản phẩm yêu thích của bạn!", "success");
                    $(".wishlist-item-count-custom").text(result.number_favorite_product);
                }
                if(result.status == 0)
                {
                    swal("Có thể bạn chưa biết !", "Sản phẩm "+name_product+" đã tồn tại trong danh sách sản phẩm ưa thích của bạn !", "info");
                }
                if(result.error)
                {
                    swal("Cảnh báo !", "Bạn cần đăng nhập cho chức năng này!", "warning");
                }
            });
        });
        $(".button_add_cart").click(function(event)
        {
            event.preventDefault();
            url = $(this).attr("href");
            name_product = $(this).attr("data-product-name");
            $.ajax(
                {
                    method : "GET",
                    url : url
                }
            ).done(function(result)
            {
                if(result.status == 1)
                {
                    swal("Thành công !","Đã thêm sản phẩm "+name_product+" vào giỏ hàng !", "success");
                    $(".cart-item-count-number").text(result.number_product_in_cart);
                    $(".price_total_cart").text(result.price_total_cart);
                }
                if(result.status == 2)
                {
                    swal("Cảnh báo !", "Trong kho chỉ còn "+result.product_less+" sản phẩm "+name_product, "warning");
                }
                if(result.status == 3)
                {
                    swal("Cảnh báo !", "Sản phẩm "+name_product+" không tồn tại !", "warning");
                }
                if(result.status == 4)
                {
                    swal("Cảnh báo !", "Sản phẩm "+name_product+" đã hết hàng !", "warning");
                }
                if(result.error)
                {
                    swal("Cảnh báo !", "Bạn cần đăng nhập cho chức năng này!", "warning");
                }
            });
        }); 
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('customer.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shop_computer\resources\views/customer/index.blade.php ENDPATH**/ ?>