<?php echo csrf_field(); ?>
<div class="form-group">
    <label>Tên Bài viết: </label>
    <input type="text" class="form-control" name="a_name" value="<?php echo e(old('a_name',isset($article->a_name)?$article->a_name:'')); ?>" placeholder="Nhập tên bài viết...">
</div>
<div class="form-group">
    <label>Mô tả bài viết: </label>
    <textarea class="form-control" rows="3" name="a_description" placeholder="Nhập mô tả bài viết..."><?php echo e(old('a_description',isset($article)?$article->a_description:"")); ?></textarea>
</div>
<div class="form-group">
    <label>Ảnh mô tả: </label>
    <?php if(isset($article->a_image)): ?>
        <img  id="img_output" class="form-control" style="width:240px;height:180px; margin-bottom:10px" src="<?php echo e(asset('upload/a_image/'.$article->a_image)); ?>"/>
    <?php else: ?>
        <img id="img_output" class="form-control" style="width:240px;height:180px; margin-bottom:10px" src="<?php echo e(asset('unimg.jpg')); ?>"/>
    <?php endif; ?>
    <input type="file" id="img_input" class="form-control col-sm-4" name="a_image"/>
</div>
<div class="form-group">
  <label>Nội dung bài viết: </label>
  <textarea class="form-control" cols="30" rows="5"  name="a_content" id="ckeditor" placeholder="Nhập nội dung bài viết"><?php echo e(old('a_content',isset($article)?$article->a_content:"")); ?></textarea>
</div>
<input type="submit" value="Lưu thông tin" class="btn btn-success btn_save_article" style="float: right"/>
<div style="clear: both"></div>
<?php $__env->startSection('javascript'); ?>
  <script>
    function readURL(input) {
      if (input.files && input.files[0]) {
        var reader = new FileReader();
        
        reader.onload = function(e) {
          $('#img_output').attr('src', e.target.result);
        }
        
        reader.readAsDataURL(input.files[0]); // convert to base64 string
      }
    }

    $("#img_input").change(function() {
      readURL(this);
    });
  </script>
  <script src="<?php echo e(asset('ckeditor/ckeditor.js')); ?>"></script>
  <script>
      CKEDITOR.replace( 'ckeditor' );
  </script>
<?php $__env->stopSection(); ?>
<?php /**PATH C:\xampp\htdocs\shop_computer\resources\views/Admin/article/form.blade.php ENDPATH**/ ?>