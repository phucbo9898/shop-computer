<?php $__env->startSection('content'); ?>
<!-- Begin Li's Breadcrumb Area -->
<div class="breadcrumb-area">
    <div class="container">
        <div class="breadcrumb-content">
            <ul>
                <li><a href="<?php echo e(route('home')); ?>">Trang chủ</a></li>
                <li class="active">Sản phẩm yêu thích</li>
            </ul>
        </div>
    </div>
</div>
<!-- Li's Breadcrumb Area End Here -->
<!--Wishlist Area Strat-->
<div class="wishlist-area pt-60 pb-60">
    <div class="container">
        <h4><center>DANH SÁCH SẢN PHẨM YÊU THÍCH CỦA BẠN </center></h4>
        <div class="row" style="margin-top: 3%">
            <div class="col-12">
                <form action="#">
                    <div class="table-content table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th class="li-product-remove">Xóa</th>
                                    <th class="li-product-thumbnail">Image</th>
                                    <th class="cart-product-name">Tên sản phẩm</th>
                                    <th class="li-product-price">Giá</th>
                                    <th class="li-product-stock-status">Tình trạng</th>
                                    <th class="li-product-add-cart">Thêm vào giỏ hàng</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="li-product-remove"><a href="<?php echo e(route('get.delete.favorite.product',$product->id)); ?>" data-product-name="<?php echo e($product->pro_name); ?>" class="delete_favorite_product"><i class="fa fa-times"></i></a></td>
                                        <td class="li-product-thumbnail"><a href="#"><img width="200px" src="<?php echo e(asset('upload/pro_image/'.$product->pro_image)); ?>" alt=""></a></td>
                                        <td class="li-product-name"><a href="#"><?php echo e($product->pro_name); ?></a></td>
                                        <td class="li-product-price"><span class="amount"><?php echo e(number_format($product->pro_price,2,',','.')); ?> VNĐ</span></td>
                                        <td class="li-product-stock-status">
                                            <?php if($product->pro_number > 10): ?>
                                            <b>Còn hàng</b>
                                            <?php elseif($product->pro_number < 10 && $product->pro_number > 0): ?>
                                                <b>Số lượng gần hết</b>
                                            <?php elseif($product->pro_number == 0): ?>
                                                <b>Hết hàng</b>
                                            <?php else: ?>
                                                <b>Không xác định</b> 
                                            <?php endif; ?>
                                        </td>
                                        <td class="li-product-add-cart"><a data-product-name="<?php echo e($product->pro_name); ?>" class="button_add_cart" href="<?php echo e(route('shopping.add.product',$product->id)); ?>">Mua hàng</a></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<!--Wishlist Area End-->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('javascript'); ?>
<script>
    $(function()
    {
        $(".delete_favorite_product").click(function(event)
        {
            event.preventDefault();
            url = $(this).attr("href");
            name_product = $(this).attr("data-product-name");
            swal({
            title: "Bạn có chắc chắn?",
            text: "Bạn có chắc chắn xóa sản phẩm "+name_product+" khỏi danh sách yêu thích!",
            icon: "info",
            buttons: ["Không","Có"],
            dangerMode: true,
            })
            .then((willDelete) => {
            if (willDelete) {
                swal("Thành công","Hệ thống chuẩn bị xóa sản phẩm này khỏi danh sách yêu thích của bạn !",'success').then(function() {
                    window.location.href = url;
                });
            }
            });
        });
        $(".button_add_cart").click(function(event)
        {
            event.preventDefault();
            url = $(this).attr("href");
            name_product = $(this).attr("data-product-name");
            $.ajax(
                {
                    method : "GET",
                    url : url
                }
            ).done(function(result)
            {
                if(result.status == 1)
                {
                    swal("Thành công !","Đã thêm sản phẩm "+name_product+" vào giỏ hàng !", "success");
                    $(".cart-item-count").text(result.number_product_in_cart);
                    $(".price_total_cart").text(result.price_total_cart);
                }
                if(result.status == 2)
                {
                    swal("Cảnh báo !", "Trong kho chỉ còn "+result.product_less+" sản phẩm "+name_product, "warning");
                }
                if(result.status == 3)
                {
                    swal("Cảnh báo !", "Sản phẩm "+name_product+" không tồn tại !", "warning");
                }
                if(result.status == 4)
                {
                    swal("Cảnh báo !", "Sản phẩm "+name_product+" đã hết hàng !", "warning");
                }
                if(result.error)
                {
                    swal("Cảnh báo !", "Bạn cần đăng nhập cho chức năng này!", "warning");
                }
            });
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('customer.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shop_computer\resources\views/customer/favoriteproduct/index.blade.php ENDPATH**/ ?>