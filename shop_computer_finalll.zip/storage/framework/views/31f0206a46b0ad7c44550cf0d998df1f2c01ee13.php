<?php if($orders): ?>
<?php $i=1?>
 <table class="table table-hover">
            <thead class="thead-dark">
                    <th scope="col">STT</th>
                    <th scope="col" style="">Tên sản phẩm</th>
                    <th scope="col">Hình ảnh</th>
                    <th scope="col">Giá</th>
                    <th scope="col">Số lượng</th>
                    <th scope="col">Thành tiền</th>
            </thead>
            <tbody>
            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="col">#<?php echo e($i++); ?></th>
                    <td><a href="<?php echo e(route('product.index',[$order->Product->pro_name_slug,$order->Product->id])); ?>"><?php echo e($order->Product->pro_name); ?></a></td>
                    <?php if($order->Product->pro_image): ?>
                        <td><img style="width:80px;height:60px" src="<?php echo e(asset('upload/pro_image/'.$order->Product->pro_image)); ?>"/></td>     
                    <?php else: ?>
                        <td><img style="width:80px;height:60px" src="<?php echo e(asset('noimg.png')); ?>"/></td>
                    <?php endif; ?>
                    
                    <?php if($order->or_sale>0): ?>
                    <td><?php echo e(number_format($order->or_price*((100-$order->or_sale)/100),0,',','.')); ?> VNĐ (-<?php echo e($order->or_sale); ?>%)<br/>
                        <span style="text-decoration: line-through;"><?php echo e(number_format($order->or_price,0,',','.')); ?> VNĐ</span>
                    </td>
                    <?php else: ?>
                        <td><?php echo e(number_format($order->or_price,0,',','.')); ?> VNĐ/ 1 sản phẩm</td>
                    <?php endif; ?>
                    <td><?php echo e($order->or_qty); ?></td>
                    <?php if($order->or_sale>0): ?>
                        <td><?php echo e(number_format(($order->or_price*((100-$order->or_sale)/100))*$order->or_qty,0,',','.')); ?> VNĐ</td>
                    <?php else: ?>
                        <td><?php echo e(number_format($order->or_price * $order->or_qty,0,',','.')); ?> VNĐ</td>
                    <?php endif; ?>   
                </tr>     
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>              
            </tbody>
        </table>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\shop_computer\resources\views/Admin/transaction/orderItem.blade.php ENDPATH**/ ?>