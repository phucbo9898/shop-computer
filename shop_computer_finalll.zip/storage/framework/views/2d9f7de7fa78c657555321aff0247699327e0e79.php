<?php if($transactions): ?>
<?php $i=1;
    $total_earn_money = 0;
 ?>
 <div id="data-statistical-date-start" data-statistical-date-start="<?php echo e($statistical_date_start); ?>"></div>
 <div id="data-statistical-date-end" data-statistical-date-end="<?php echo e($statistical_date_end); ?>"></div>
<table class="table table-hover table-bordered">
    <thead class="thead-dark">
            <th scope="col">STT</th>
            <th scope="col" style="">Tên Sản phẩm</th>
            <th scope="col">Số lượng</th>
            <th scope="col">Đơn giá</th>
            <th scope="col">Giảm giá</th>
            <th scope="col">Thành tiền</th>
            <th scope="col">Người mua</th>
            <th>Mã giao dịch</th>
    </thead>
    <tbody>
        <tr></tr>
    <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php $__currentLoopData = $transaction->Order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($i++); ?></td>
                <td><?php echo e($order->Product->pro_name); ?></td>
                <td><?php echo e($order->or_qty); ?></td>
                <td><?php echo e(number_format($order->or_price,0,',','.')); ?> VNĐ</td>
                <td><?php echo e($order->or_sale>0?(number_format($order->or_price*(100-$order->or_sale)/100,0,',','.'))."VNĐ (-".$order->or_sale."%)":"Không giảm giá"); ?></td>
                <td><?php echo e($order->or_sale>0?number_format($order->or_qty*($order->or_price*(100-$order->or_sale)/100),0,'.','.'):number_format($order->or_qty*$order->or_price,0,',','.')); ?> VNĐ</td>
                <td><?php echo e($transaction->User->name); ?></td>
                <td><?php echo e($transaction->id); ?></td>
                <?php $total_earn_money = $total_earn_money + ($order->or_sale>0?$order->or_qty*($order->or_price*(100-$order->or_sale)/100):$order->or_qty*$order->or_price) ?>   
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>       
            <tr>
                <td colspan="6" style="text-align: center;font-weight: bold;font-size: 20px;">Tổng tiền:</td>
                <td colspan="2" style="text-align: center;font-weight: bold;font-size: 20px;"><?php echo e(number_format($total_earn_money,'0',',','.')); ?> VNĐ</td>
            </tr>
    </tbody>
</table>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\shop_computer\resources\views/admin/statistics/listStatistics.blade.php ENDPATH**/ ?>