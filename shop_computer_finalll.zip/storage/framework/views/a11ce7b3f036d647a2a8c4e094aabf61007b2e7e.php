<?php $__env->startSection('content'); ?>
<style>
  .rating .active{
    color: #ff9705 !important;
  }
</style>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Sản phẩm - Danh sách</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo e(route('admin.home')); ?>">Trang chủ</a></li>
              <li class="breadcrumb-item active">Sản phẩm - Danh sách</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">

      <!-- Default box -->
      <div class="card">
        <div class="card-body">
          <?php if(Session::has('create_product_success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
              <strong>Thành công !</strong> <?php echo e(Session::get('create_product_success')); ?>

              <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
          <?php endif; ?>
          <?php if(Session::has('edit_product_success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
              <strong>Thành công !</strong> <?php echo e(Session::get('edit_product_success')); ?>

              <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
          <?php endif; ?>
          <?php if(Session::has('delete_product_success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
              <strong>Thành công !</strong> <?php echo e(Session::get('delete_product_success')); ?>

              <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
          <?php endif; ?>
            <table class="table table-hover table-striped" id="dataTable">
                <thead class="thead-dark">
                    <th>ID</th>
                    <th>Sản phẩm</th>
                    <th>Loại sản phẩm</th>
                    <th>Ảnh</th>
                    <th style="width: 11%;">Trạng thái</th>
                    <th>Nổi bật</th>
                    <th style="width: 12%;">Thao tác</th>
                </thead>
                <tbody>
                  <?php if(isset($products)): ?>
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                        <td><?php echo e($pro->id); ?></td>
                        <td>
                          <b><?php echo e($pro->pro_name); ?></b><br/>
                          <ul style="padding:0px">
                            <li>Số lượng: <?php echo e($pro->pro_number); ?></li>
                            <li>Giá: <?php echo e(number_format($pro->pro_price,0,',','.')); ?> VNĐ</li>
                            <?php if($pro->pro_sale): ?>
                            <li>Đang giảm giá ( -<?php echo e($pro->pro_sale); ?>% )</li>
                            <?php else: ?>
                            <li>Không giảm giá</li>
                            <?php endif; ?>
                            <li>
                              <?php
                              $point= 0;
                              if($pro->pro_number_of_reviewers>0){
                                $point= round($pro->pro_total_star/$pro->pro_number_of_reviewers);
                              }
                              ?>
                              Đánh giá: <span class="rating">
                                <?php for($i=1; $i <= 5; $i++): ?>
                                  <i class="fa fa-star <?php echo e($i<=$point ? 'active':''); ?>" style="color:#999"></i>
                                <?php endfor; ?>
                                <?php if($pro->pro_number_of_reviewers>0): ?>
                                  <?php echo e($point); ?> sao
                                <?php else: ?>
                                  Chưa đánh giá
                                <?php endif; ?>
                              </span>
                            </li>
                          </ul>
                        </td>
                        <td><?php echo e($pro->Category->c_name); ?></td>
                        <td>
                          <?php if($pro->pro_image): ?>
                            <img style="width:80px;height:80px" src="<?php echo e(asset('upload/pro_image/'.$pro->pro_image)); ?>" alt="No Avatar"/>
                          <?php else: ?>
                          <img style="width:80px;height:80px" src="<?php echo e(asset('noimg.png')); ?>" alt="No Avatar"/>
                          <?php endif; ?>
                        </td>
                        <td style="text-align: center"><a href="<?php echo e(route('admin.product.handle',['status',$pro->id])); ?>" class="badge badge-<?php echo e(($pro->pro_status==1)?"success":"danger"); ?>"><?php echo e(($pro->pro_status==1)?"Công khai":"Riêng tư"); ?></a></td>
                        <td style="text-align: center"><a href="<?php echo e(route('admin.product.handle',['hot',$pro->id])); ?>" class="badge badge-<?php echo e(($pro->pro_hot==1)?"success":"secondary"); ?>"><?php echo e(($pro->pro_hot==1)?"Có":"Không"); ?></a></td>
                        <td>
                          <a href="<?php echo e(route('admin.product.edit',$pro->id)); ?>" class="btn btn-success btn-circle"><i class="fas fa-edit"></i></a>
                          <a href="<?php echo e(route('admin.product.handle',['delete',$pro->id])); ?>" data-id="<?php echo e($pro->id); ?>" class="btn_delete_sweet btn btn-danger btn-circle"><i class="fas fa-trash-alt"></i></a>
                        </td>
                      </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php endif; ?>
                </tbody>
            </table>
        </div>
        <!-- /.card-body -->
      </div>
      <!-- /.card -->

    </section>
    <!-- /.content -->
</div>
 <!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('javascript'); ?>
<script>
  $(document).ready( function () {
    $('#dataTable').DataTable({
      "order": [[ 0, "desc" ]],
      "language" : {
        "decimal":        "",
        "emptyTable":     "Không có dữ liệu hiển thị trong bảng",
        "info":           "Đang hiển thị bản ghi _START_ đến _END_ trên _TOTAL_ bản ghi",
        "infoEmpty":      "Hiển thị 0 đến 0 của 0 bản ghi",
        "infoFiltered":   "(đã lọc từ _MAX_ bản ghi)",
        "infoPostFix":    "",
        "thousands":      ",",
        "lengthMenu":     "Hiển thị _MENU_ bản ghi",
        "loadingRecords": "Đang tải...",
        "processing":     "Đang xử lý...",
        "search":         "Tìm kiếm:",
        "zeroRecords":    "Không có bản ghi nào được tìm thấy",
        "paginate": {
            "first":      "Đầu",
            "last":       "Cuối",
            "next":       "Tiếp",
            "previous":   "Trước"
        },
        "aria": {
            "sortAscending":  ": activate to sort column ascending",
            "sortDescending": ": activate to sort column descending"
        }
      }
    });
  });
</script>
<script>
  $(".btn_delete_sweet").click(function(e)
  {
    e.preventDefault();
    url = $(this).attr('href');
    id= $(this).attr('data-id');
    swal({
            title: "Bạn có chắc chắn?",
            text: "Bạn có chắc chắn muốn xóa sản phẩm ID="+id+" không ? Điều này sẽ ảnh hưởng đến liên kết dữ liệu !!",
            icon: "info",
            buttons: ["Không","Có"],
            dangerMode: true,
            })
            .then((willDelete) => {
            if (willDelete) {
                swal("Thành công","Hệ thống chuẩn bị xóa sản phẩm mang ID ="+id+" !",'success').then(function() {
                window.location.href = url;
                });
            }
        });
  });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shop_computer\resources\views/admin/product/index.blade.php ENDPATH**/ ?>