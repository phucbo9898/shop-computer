<!-- Begin Footer Area -->
<div class="footer">
    <!-- Begin Footer Static Top Area -->
    <div class="footer-static-top">
        <div class="container">
            <!-- Begin Footer Shipping Area -->
            <div class="footer-shipping pt-60 pb-55 pb-xs-25">
                <div class="row">
                    <!-- Begin Li's Shipping Inner Box Area -->
                    <div class="col-lg-3 col-md-6 col-sm-6 pb-sm-55 pb-xs-55">
                        <div class="li-shipping-inner-box">
                            <div class="shipping-icon">
                                <img src="<?php echo e(asset('images/shipping-icon/1.png')); ?>" alt="Shipping Icon">
                            </div>
                            <div class="shipping-text">
                                <h2>Miễn phí vận chuyển</h2>
                                <p>Miễn phí trả lại. Hãy xem thanh toán cho ngày giao dịch.</p>
                            </div>
                        </div>
                    </div>
                    <!-- Li's Shipping Inner Box Area End Here -->
                    <!-- Begin Li's Shipping Inner Box Area -->
                    <div class="col-lg-3 col-md-6 col-sm-6 pb-sm-55 pb-xs-55">
                        <div class="li-shipping-inner-box">
                            <div class="shipping-icon">
                                <img src="<?php echo e(asset('images/shipping-icon/2.png')); ?>" alt="Shipping Icon">
                            </div>
                            <div class="shipping-text">
                                <h2>Tiết kiệm chi phí</h2>
                                <p>Giá thành sản phẩm sẽ vì lợi ích của khách hàng.</p>
                            </div>
                        </div>
                    </div>
                    <!-- Li's Shipping Inner Box Area End Here -->
                    <!-- Begin Li's Shipping Inner Box Area -->
                    <div class="col-lg-3 col-md-6 col-sm-6 pb-xs-30">
                        <div class="li-shipping-inner-box">
                            <div class="shipping-icon">
                                <img src="<?php echo e(asset('images/shipping-icon/3.png')); ?>" alt="Shipping Icon">
                            </div>
                            <div class="shipping-text">
                                <h2>Bảo mật thông tin</h2>
                                <p>Thông tin của khách hàng sẽ không được chia sẻ với bên thứ ba.</p>
                            </div>
                        </div>
                    </div>
                    <!-- Li's Shipping Inner Box Area End Here -->
                    <!-- Begin Li's Shipping Inner Box Area -->
                    <div class="col-lg-3 col-md-6 col-sm-6 pb-xs-30">
                        <div class="li-shipping-inner-box">
                            <div class="shipping-icon">
                                <img src="<?php echo e(asset('images/shipping-icon/4.png')); ?>" alt="Shipping Icon">
                            </div>
                            <div class="shipping-text">
                                <h2>Hỗ trợ 24/7</h2>
                                <p>Nếu bạn có câu hỏi? Hãy liên hệ ngay với chúng tôi.</p>
                            </div>
                        </div>
                    </div>
                    <!-- Li's Shipping Inner Box Area End Here -->
                </div>
            </div>
            <!-- Footer Shipping Area End Here -->
        </div>
    </div>
    <!-- Footer Static Top Area End Here -->
    <!-- Begin Footer Static Middle Area -->
    <div class="footer-static-middle">
        <div class="container">
            <div class="footer-logo-wrap pt-50 pb-35">
                <div class="row">
                    <!-- Begin Footer Logo Area -->
                    <div class="col-lg-4 col-md-6">
                        <div class="footer-logo">
                            <img src="<?php echo e(asset('images/menu/logo/1.jpg')); ?>" alt="Footer Logo">
                            <p class="info">
                                Website này hiện tại đang trong giai đoạn thử nghiệm và phát triển để hoàn thiện hơn trước khi đưa vào kinh doanh, thương mại hóa.
                            </p>
                        </div>
                        <ul class="des">
                            <li>
                                <span>Địa chỉ: </span>
                                41A Đường Phú Diễn, Cầu Diễn, Bắc Từ Liêm, Hà Nội
                            </li>
                            <li>
                                <span>Số điện thoại: </span>
                                <a href="#">0942674663</a>
                            </li>
                            <li>
                                <span>Email: </span>
                                <a href="mailto://trungle87864@gmail.com">trungle87864@gmail.com</a>
                            </li>
                        </ul>
                    </div>
                    <!-- Footer Logo Area End Here -->
                    <!-- Begin Footer Block Area -->
                    <div class="col-lg-2 col-md-3 col-sm-6">
                        <div class="footer-block">
                            <h3 class="footer-block-title">Nổi Bật</h3>
                            <ul>
                                <li><a href="#">Miến phí vận chuyển</a></li>
                                <li><a href="#">Tiết kiệm chi phí</a></li>
                                <li><a href="#">Bảo mật</a></li>
                                <li><a href="#">Hỗ trợ 24/7</a></li>
                            </ul>
                        </div>
                    </div>
                    <!-- Footer Block Area End Here -->
                    <!-- Begin Footer Block Area -->
                    <div class="col-lg-2 col-md-3 col-sm-6">
                        <div class="footer-block">
                            <h3 class="footer-block-title">Tính năng</h3>
                            <ul>
                                <li><a href="<?php echo e(route('home')); ?>">Trang chủ</a></li>
                                <li><a href="<?php echo e(route('article.index')); ?>">Bài viết</a></li>
                                <li><a href="<?php echo e(route('about.us')); ?>">Giới thiệu</a></li>
                                <li><a href="<?php echo e(route('contact')); ?>">Liên hệ</a></li>
                            </ul>
                        </div>
                    </div>
                    <!-- Footer Block Area End Here -->
                    <!-- Begin Footer Block Area -->
                    <div class="col-lg-4">
                        <div class="footer-block">
                            <h3 class="footer-block-title">Fanpage Facebook</h3>
                            <iframe src="https://www.facebook.com/plugins/page.php?href=https%3A%2F%2Fwww.facebook.com%2FKinh-doanh-linh-ki%E1%BB%87n-m%C3%A1y-t%C3%ADnh-Gaming-106134001140160%2F&tabs=messages&width=340&height=333&small_header=false&adapt_container_width=true&hide_cover=false&show_facepile=true&appId=1429073443913134" width="340" height="333" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true" allow="encrypted-media"></iframe>
                        </div>
                        <!-- Begin Footer Newsletter Area -->
                        
                        <!-- Footer Newsletter Area End Here -->
                    </div>
                    <!-- Footer Block Area End Here -->
                </div>
            </div>
        </div>
    </div>
    <!-- Footer Static Middle Area End Here -->
    <!-- Begin Footer Static Bottom Area -->
    <div class="footer-static-bottom pt-55 pb-55">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <!-- Begin Footer Links Area -->
                    
                    <!-- Footer Links Area End Here -->
                    <!-- Begin Footer Payment Area -->
                    
                    <!-- Footer Payment Area End Here -->
                    <!-- Begin Copyright Area -->
                    
                    <!-- Copyright Area End Here -->
                </div>
            </div>
        </div>
    </div>
    <!-- Footer Static Bottom Area End Here -->
</div>
<!-- Footer Area End Here --><?php /**PATH C:\xampp\htdocs\shop_computer\resources\views/customer/components/footer.blade.php ENDPATH**/ ?>