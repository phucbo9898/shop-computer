<?php $__env->startSection('content'); ?>
<style>
    .sort_product li{
        padding: 6px 0px;
    }
</style>
<!-- Begin Li's Breadcrumb Area -->
<div class="breadcrumb-area">
    <div class="container">
        <div class="breadcrumb-content">
            <ul>
                <li><a href="<?php echo e(route('home')); ?>">Trang chủ</a></li>
                <li class="active">Loại sản phẩm: <?php echo e($category->c_name); ?></li>
            </ul>
        </div>
    </div>
</div>
<!-- Li's Breadcrumb Area End Here -->
<!-- Begin Li's Content Wraper Area -->
<div class="content-wraper pt-60 pb-60 pt-sm-30">
    <div class="container">
        <div class="row">
            <div class="col-lg-9 order-1 order-lg-2">
                
                <!-- shop-top-bar start -->
                
                <!-- shop-top-bar end -->
                <!-- shop-products-wrapper start -->
                <?php if(count($products)>0): ?>
                <div class="shop-products-wrapper">
                    <div class="tab-content">
                        <div id="grid-view" class="tab-pane fade active show" role="tabpanel">
                            <div class="product-area shop-product-area">
                                <div class="row" style="    margin-top: -82px;">
                                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-lg-4 col-md-4 col-sm-6 mt-40">
                                            <!-- single-product-wrap start -->
                                            <div class="single-product-wrap">
                                                <div class="product-image">
                                                    <a href="<?php echo e(route('product.index',[$product->pro_name_slug,$product->id])); ?>">
                                                        <?php if(isset($product->pro_image)): ?>
                                                        <img src="<?php echo e(asset('upload/pro_image/'.$product->pro_image)); ?>" alt="Li's Product Image">
                                                        <?php else: ?>
                                                            <img src="<?php echo e(asset('noimg.png')); ?>" alt="Li's Product Image">
                                                        <?php endif; ?>
                                                    </a>
                                                    <?php if($product->pro_hot == 1): ?>
                                                        <span class="sticker">Hot</span>
                                                    <?php endif; ?>
                                                </div>
                                                <div class="product_desc">
                                                    <div class="product_desc_info">
                                                        <div class="product-review">
                                                            <h5 class="manufacturer">
                                                                
                                                                <div class="rating-box">
                                                                    <?php
                                                                    $point= 0;
                                                                    if($product->pro_number_of_reviewers>0){
                                                                        $point= round($product->pro_total_star/$product->pro_number_of_reviewers);
                                                                    }
                                                                    else {
                                                                        $point = -1;
                                                                    }
                                                                    ?>
                                                                    <ul class="rating">
                                                                        <?php if($point == -1): ?>
                                                                        <li style="color: #a4a4a4;
                                                                        font-size: 13px;
                                                                        text-transform: capitalize;
                                                                        transition: all 0.3s ease-in-out;">Chưa đánh giá</li>
                                                                        <?php else: ?>
                                                                        Đánh Giá: 
                                                                            <?php for($i=1; $i<=5; $i++): ?>
                                                                                <li class="<?php echo e($i<=$point ? '':'no-star'); ?>"><i class="fa fa-star"></i></li>
                                                                            <?php endfor; ?>
                                                                        <?php endif; ?>
                                                                    </ul>
                                                                </div>
                                                            </h5>
                                                           
                                                        </div>
                                                        <h4><a class="product_name" href="<?php echo e(route('product.index',[$product->pro_name_slug,$product->id])); ?>"><?php echo e($product->pro_name); ?></a></h4>
                                                        <div class="price-box">
                                                            <?php if($product->pro_sale>0): ?>
                                                                <span class="new-price new-price-2"><?php echo e(number_format(($product->pro_price*(100-$product->pro_sale))/100,0,",",".")); ?> VNĐ</span>
                                                                <span class="discount-percentage">-<?php echo e($product->pro_sale); ?>%</span><br/>
                                                                <div class="old-price" style="padding-top: 6px"><?php echo e(number_format($product->pro_price,0,",",".")); ?> VNĐ</div>
                                                            <?php else: ?>
                                                                <span class="new-price"><?php echo e(number_format($product->pro_price,0,",",".")); ?> VNĐ</span>
                                                            <?php endif; ?>
                                                        </div>
                                                    </div>
                                                    <div class="add-actions">
                                                        <ul class="add-actions-link">
                                                            <li class="add-cart active"><a class="button_add_cart" data-product-name="<?php echo e($product->pro_name); ?>" href="<?php echo e(route('shopping.add.product',$product->id)); ?>">Mua sản phẩm</a></li>
                                                            <li><a href="<?php echo e(route('product.index',[$product->pro_name_slug,$product->id])); ?>" title="quick view" class="quick-view-btn"><i class="fa fa-eye"></i></a></li>
                                                            <li><a class="links-details button_add_favorite_product" data-product-name="<?php echo e($product->pro_name); ?>" href="<?php echo e(route('get.add.favorite.product',$product->id)); ?>"><i class="fa fa-heart-o"></i></a></li>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>
                                            <!-- single-product-wrap end -->
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
                                </div>
                            </div>
                        </div>
                    <div>
                        <div style="margin-top:88px; text-align: center"><?php echo e($checklink==1?$products->links():''); ?></div>
                    </div>
                        
                        
                    </div>
                </div>
                <?php else: ?>
                <div style="margin-top: 125px; margin-left: 300px; font-size: 20px; color: #a4a4a4">Không có sản phẩm  nào !!!</div>
                <?php endif; ?>
                <!-- shop-products-wrapper end -->
            </div>
            <div class="col-lg-3 order-2 order-lg-1">
                <!--sidebar-categores-box start  -->
                <div class="">
                    <div style="text-align: center">
                        <h2><b style="color: #a4a4a4"><a href="<?php echo e(route('category.index',[$category->c_name_slug,$category->id])); ?>" style="text-transform: uppercase; text-align: center">► <?php echo e($category->c_name); ?></a></b></h2>
                        <hr style="margin: 30px 0"/>
                    </div>
                </div>
                <!--sidebar-categores-box end  -->
                <!--sidebar-categores-box start  -->
                <div class="sidebar-categores-box mt-50">
                    <div class="sidebar-title">
                        <h2><b>Sắp xếp</b></h2>
                    </div>
                    <!-- filter-sub-area start -->
                    <div class="filter-sub-area">
                        <div class="filter-sub-titel">Khoảng giá: </div>
                        <div style="padding-left: 5%">
                            <ul class="sort_product" style="padding: 6px">
                                <li><a href="<?php echo e(route('category.index.order',[$category->c_name_slug,$category->id,'d1t'])); ?>">Dưới 1 triệu VNĐ</a></li>
                                <li><a href="<?php echo e(route('category.index.order',[$category->c_name_slug,$category->id,'1t-10t'])); ?>">1 triệu - 10 triệu VNĐ</a></li>
                                <li><a href="<?php echo e(route('category.index.order',[$category->c_name_slug,$category->id,'10t-20t'])); ?>">10 triệu - 20 triệu VNĐ</a></li>
                                <li><a href="<?php echo e(route('category.index.order',[$category->c_name_slug,$category->id,'20t-50t'])); ?>">20 triệu - 50 triệu VNĐ</a></li>
                                <li><a href="<?php echo e(route('category.index.order',[$category->c_name_slug,$category->id,'t50t'])); ?>">Trên 50 triệu VNĐ</a></li>
                            </ul>
                        </div>
                        <div class="filter-sub-titel mt-3">Khác: </div>
                        <div style="padding-left: 5%">
                            <ul class="sort_product" style="padding: 6px">
                                <li><a href="<?php echo e(route('category.index.order',[$category->c_name_slug,$category->id,'az'])); ?>">Theo chữ cái A-Z</a></li>
                                <li><a href="<?php echo e(route('category.index.order',[$category->c_name_slug,$category->id,'za'])); ?>">Theo chữ cái Z-A</a></li>
                                <li><a href="<?php echo e(route('category.index.order',[$category->c_name_slug,$category->id,'mn'])); ?>">Sản phẩm mới trước</a></li>
                                <li><a href="<?php echo e(route('category.index.order',[$category->c_name_slug,$category->id,'cn'])); ?>">Sản phẩm cũ trước</a></li>
                                <li><a href="<?php echo e(route('category.index.order',[$category->c_name_slug,$category->id,'td'])); ?>">Giá tăng dần</a></li>
                                <li><a href="<?php echo e(route('category.index.order',[$category->c_name_slug,$category->id,'gd'])); ?>">Giá giảm dần</a></li>
                            </ul>
                        </div>
                        <?php $__currentLoopData = $category->Attributes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attributes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="filter-sub-titel mt-3"><?php echo e($attributes->at_name); ?>: </div>
                        <div style="padding-left: 5%">
                            <ul class="sort_product" style="padding: 6px">
                                <?php $__currentLoopData = $attributes->AttributeValue->sortbyDesc('atv_value'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attributeValue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><a href="<?php echo e(route('category.index.order.attribute',[$category->c_name_slug,$category->id,$attributeValue->id])); ?>"><?php echo e($attributeValue->atv_value); ?></a></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                   
                            </ul>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     </div>
                    <!-- filter-sub-area end -->
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Content Wraper Area End Here -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('javascript'); ?>
<script>
    $(function(){
        $(".button_add_favorite_product").click(function(event)
        {
            event.preventDefault();
            name_product = $(this).attr("data-product-name");
            url = $(this).attr("href");
            $.ajax(
                {
                    method : "GET",
                    url : url
                }
            ).done(function(result)
            {
                if(result.status == 1)
                {
                    swal("Thành công !","Đã thêm sản phẩm "+name_product+" vào sản phẩm yêu thích của bạn!", "success");
                    $(".wishlist-item-count-custom").text(result.number_favorite_product);
                }
                if(result.status == 0)
                {
                    swal("Có thể bạn chưa biết !", "Sản phẩm "+name_product+" đã tồn tại trong danh sách sản phẩm ưa thích của bạn !", "info");
                }
                if(result.error)
                {
                    swal("Cảnh báo !", "Bạn cần đăng nhập cho chức năng này!", "warning");
                }
            });
        });
        $(".button_add_cart").click(function(event)
        {
            event.preventDefault();
            url = $(this).attr("href");
            name_product = $(this).attr("data-product-name");
            $.ajax(
                {
                    method : "GET",
                    url : url
                }
            ).done(function(result)
            {
                if(result.status == 1)
                {
                    swal("Thành công !","Đã thêm sản phẩm "+name_product+" vào giỏ hàng !", "success");
                    $(".cart-item-count-number").text(result.number_product_in_cart);
                    $(".price_total_cart").text(result.price_total_cart);
                }
                if(result.status == 2)
                {
                    swal("Cảnh báo !", "Trong kho chỉ còn "+result.product_less+" sản phẩm "+name_product, "warning");
                }
                if(result.status == 3)
                {
                    swal("Cảnh báo !", "Sản phẩm "+name_product+" không tồn tại !", "warning");
                }
                if(result.status == 4)
                {
                    swal("Cảnh báo !", "Sản phẩm "+name_product+" đã hết hàng !", "warning");
                }
                if(result.error)
                {
                    swal("Cảnh báo !", "Bạn cần đăng nhập cho chức năng này!", "warning");
                }
            });
        }); 
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('customer.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shop_computer\resources\views/customer/category/index.blade.php ENDPATH**/ ?>