<?php echo csrf_field(); ?>
<div class="row">
  <div class="col-md-8 pl-3 pr-3">
    <div class="form-group">
      <label>Tên sản phẩm: </label>
      <input type="text" class="form-control" name="pro_name" value="<?php echo e(old('pro_name',isset($product)?$product->pro_name:"")); ?>" placeholder="Nhập tên sản phẩm...">
    </div>
    <div class="form-group" style="display: none">
      <label>Mô tả sản phẩm: </label>
      <textarea name="pro_description" placeholder="Nhập mô tả sản phẩm..." rows="3" class="form-control"><?php echo e(old('pro_description',isset($product->pro_description)?$product->pro_description:"")); ?>Bỏ qua</textarea>
    </div>
    <div class="form-group">
      <label>Nội dung sản phẩm: </label>
      <textarea name="pro_content" id="ckeditor" rows="5" class="form-control" placeholder="Nhập nội dung sản phẩm..."><?php echo e(old('pro_content',isset($product->pro_content)?$product->pro_content:"")); ?></textarea>
    </div>
    <div id="attribute_for_product">
    </div>
  </div>
  <div class="col-md-4 pl-3 pr-3">
    <div class="form-group">
      <label>Loại sản phẩm</label>
      <select name="pro_category_id" id="select_pro_category_id" class="form-control">
        <option value="">---------- Chọn loại sản phẩm ----------</option>
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value="<?php echo e($category->id); ?>" <?php echo e(old('pro_category_id',isset($product->pro_category_id)?(($product->pro_category_id==$category->id)?"selected":""):"")); ?>><?php echo e($category->c_name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>
    </div>
    <div class="form-group">
      <label>Giá sản phẩm: </label>
      <input type="number" class="form-control" name="pro_price" value="<?php echo e(old('pro_price',isset($product->pro_price)?$product->pro_price:"")); ?>" placeholder="Nhập giá sản phẩm...">
    </div>
    <div class="form-group">
      <label>Giảm giá: </label>
      <input type="number" class="form-control" name="pro_sale" value="<?php echo e(old('pro_sale',isset($product->pro_sale)?$product->pro_sale:"")); ?>" placeholder="Giảm giá sản phẩm...">
    </div>
    <div class="form-group">
      <label>Ảnh minh họa:</label>
      <?php if(isset($product->pro_image)): ?>
          <img  id="img_output" style="width:240px;height:180px; margin-bottom:10px" src="<?php echo e(asset('upload/pro_image/'.$product->pro_image)); ?>"/>
      <?php else: ?>
          <img id="img_output" style="width:240px;height:180px; margin-bottom:10px" src="<?php echo e(asset('unimg.jpg')); ?>"/>
      <?php endif; ?>
      <input type="file" name="pro_image" id="img_input" class="form-control"/>
    </div>
  </div>
</div>
<input type="submit" value="Lưu thông tin" class="btn btn-success mr-3 btn_save_product" style="float: right"/>
<div style="clear: both"></div>
<?php $__env->startSection('javascript'); ?>
  <script>
    function readURL(input) {
      if (input.files && input.files[0]) {
        var reader = new FileReader();
        
        reader.onload = function(e) {
          $('#img_output').attr('src', e.target.result);
        }
        
        reader.readAsDataURL(input.files[0]); // convert to base64 string
      }
    }

    $("#img_input").change(function() {
      readURL(this);
    });
  </script>
  <script>
    $(function(){
      $("#select_pro_category_id").change(function(){
        var selected = $(this).children("option:selected").val();
        var url  = "<?php echo e(route('admin.ajax.get.attribute')); ?>";
        if(selected != ''){
          $.ajax(
            {
              type : "GET",
              url : url,
              data : {
                pro_category_id : selected
              }
            }
          ).done(function(result){
            $("#attribute_for_product").html('').append(result);
          });
        }
      });
      // get category current
      var valueCategoryCurrent= $("#select_pro_category_id").children("option:selected").val();
      var url  = "<?php echo e(route('admin.ajax.get.attribute')); ?>";
      var id = "<?php echo e(isset($product)?$product->id:"0"); ?>"
      $.ajax(
            {
              type : "GET",
              url : url,
              data : {
                pro_category_id : valueCategoryCurrent,
                id : id
                
              }
            }
          ).done(function(result){
            $("#attribute_for_product").html('').append(result);
          });
    });
  </script>
  <script src="<?php echo e(asset('ckeditor/ckeditor.js')); ?>"></script>
  <script>
      CKEDITOR.replace( 'ckeditor' );
  </script>
<?php $__env->stopSection(); ?>
<?php /**PATH C:\xampp\htdocs\shop_computer\resources\views/Admin/product/form.blade.php ENDPATH**/ ?>