<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateOrdersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('orders', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('or_transaction_id')->unsigned()->nullable()->length(10);
            $table->integer('or_product_id')->unsigned()->nullable()->length(10);
            $table->tinyInteger('or_qty')->default(0);
            $table->integer('or_price')->default(0);
            $table->tinyInteger('or_sale')->default(0);
            $table->timestamps();
            $table->foreign('or_transaction_id')->references('id')->on('transactions')->onDelete('set null');
            $table->foreign('or_product_id')->references('id')->on('products')->onDelete('set null');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('orders');
    }
}
